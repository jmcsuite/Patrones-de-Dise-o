﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MessagingToolkit.QRCode.Codec;
using MessagingToolkit.QRCode.Codec.Data;
using Newtonsoft.Json;
using System.Drawing;

namespace TiendaAutoservicio
{
    class QRReader
    {
        public QRReader() { }

        public Pedido ReadFile(string file) {

            using (Image imgg = Image.FromFile(file)) {
                QRCodeDecoder decoder = new QRCodeDecoder();
                QRCodeImage img = new QRCodeBitmapImage(imgg as Bitmap);
                string datas = decoder.Decode(img);
                Pedido pr = JsonConvert.DeserializeObject<Pedido>(datas);
                pr.AfterSerialize();
                return pr;
            }
            
            
        }
    }
}
