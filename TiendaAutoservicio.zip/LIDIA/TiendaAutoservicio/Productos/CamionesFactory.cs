﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    class CamionesFactory : IProductosFactory
    {
        private IProductosFactory productoFactory_;
        public CamionesFactory(IProductosFactory productoFactory)
        {
            productoFactory_ = productoFactory;
        }
        public Producto CrearPan()
        {
            Producto pr = productoFactory_.CrearPan();
            pr.setCantidad(270);
            return pr;
        }

        public Producto CrearProducto(EnumProductos tipoProducto)
        {
            IProductosFactory factory = (IProductosFactory)this;
            if (tipoProducto == EnumProductos.Pan)
            {
                return factory.CrearPan();
            }
            if (tipoProducto == EnumProductos.Refresco)
            {
                return factory.CreateRefresco();
            }
            if (tipoProducto == EnumProductos.Verdura)
            {
                return factory.CrearVerdura();
            }

            throw new Exception("Producto de tipo " + tipoProducto.ToString() + " no esta implementado");
        }

        public Producto CrearVerdura()
        {
            Producto pr = productoFactory_.CrearVerdura();
            pr.setCantidad(95);
            return pr;
           
        }

        public Producto CreateRefresco()
        {
            Producto pr = productoFactory_.CreateRefresco();
            pr.setCantidad(120);
            return pr;
            
        }
    }
}
