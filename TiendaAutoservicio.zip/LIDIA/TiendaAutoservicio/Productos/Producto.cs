﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    // Estructura Basica de un Producto. Cada Producto tiene un id, nombre y precio fijo.
    // La cantidad requerida de un producto puede variar
    class Producto
    {
        public int idProducto_;
        public string nombreProducto_;
        public float precio_;
        public int cantidad_ = -1;

        public Producto(int idProducto, string nombreProducto, float precio)
        {
            idProducto_ = idProducto;
            nombreProducto_ = nombreProducto;
            precio_ = precio;
        }
        public void setCantidad(int cantidad)
        {
            cantidad_ = cantidad; 
        }

        public int getID()
        {
            return idProducto_;
        }

        public string getNombre()
        {
            return nombreProducto_;
        }

        public float getPrecio()
        {
            return precio_;
        }

        public int getCantidad()
        {
            if(precio_ == -1)
            {
                throw (new Exception("Cantidad de producto no inicializada"));
            }
            return cantidad_;
        }
    }
}
