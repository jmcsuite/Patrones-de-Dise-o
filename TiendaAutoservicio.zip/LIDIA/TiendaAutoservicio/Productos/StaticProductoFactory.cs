﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    // Implementacion que usa valores fijos para sacar los valores de los productos
    class StaticProductoFactory : IProductosFactory
    {
        private const int idPan = (int)EnumProductos.Pan;
        private const string nombrePan = "Pieza de Pan";
        private const float precioPan = 5.5f;

        private const int idRefresco = (int)EnumProductos.Refresco;
        private const string nombreRefresco = "Botella de Refresco";
        private const float precioRefresco = 12.90f;

        private const int idVerdura = (int)EnumProductos.Verdura;
        private const string nombreVerdura = "Kg de Verdura";
        private const float precioVerdura = 35f;

        public StaticProductoFactory() { }

        Producto IProductosFactory.CrearPan()
        {
            return new Producto(idPan, nombrePan, precioPan);
        }

        Producto IProductosFactory.CrearVerdura()
        {
            return new Producto(idVerdura, nombreVerdura, precioVerdura);
        }

        Producto IProductosFactory.CreateRefresco()
        {
            return new Producto(idRefresco, nombreRefresco, precioRefresco);
        }

        Producto IProductosFactory.CrearProducto(EnumProductos tipoProducto)
        {
            IProductosFactory factory = (IProductosFactory)this;
            if(tipoProducto == EnumProductos.Pan)
            {
                return factory.CrearPan();
            }
            if (tipoProducto == EnumProductos.Refresco)
            {
                return factory.CreateRefresco();
            }
            if (tipoProducto == EnumProductos.Verdura)
            {
                return factory.CrearVerdura();
            }

            throw new Exception("Producto de tipo " + tipoProducto.ToString() + " no esta implementado");
        }

    }
}
