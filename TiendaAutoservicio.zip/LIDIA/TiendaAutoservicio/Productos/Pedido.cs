﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    // Estructura de un pedido.
    // Un pedido pertenece a una tienda y tiene una lista indefinida de productos
    class Pedido
    {


        public int idTienda_;
        public string nombreTienda_;
        private List<Producto> productos_;
        public Producto[] productosArray;
         
        public Pedido(int idTienda, string nombreTienda)
        {
            idTienda_ = idTienda;
            nombreTienda_ = nombreTienda;
            productos_ = new List<Producto>();
        }

        public int GetIdTienda()
        {
            return idTienda_;
        }

        public string GetNombreTienda()
        {
            return nombreTienda_;
        }

        public List<Producto> GetProductos()
        {
            return productos_;
        }

        public void AddProducto(Producto pr)
        {
            productos_.Add(pr);
        }

        public void BeforeSerialize()
        {
            productosArray = productos_.ToArray();
        }

        public void AfterSerialize()
        {
            productos_ = new List<Producto>(productosArray);
        }

        public float Costo()
        {
            float costo = 0.0f;
            foreach(Producto pr in productos_)
            {
                costo += pr.precio_*pr.cantidad_;
            }
            return costo;
        }
    }
}
