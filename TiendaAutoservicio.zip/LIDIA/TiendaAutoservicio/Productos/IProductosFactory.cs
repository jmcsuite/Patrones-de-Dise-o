﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    // Enum con los Productos disponibles por el momento
    enum EnumProductos
    {
        Refresco,
        Pan,
        Verdura,
        Dummy
    }
    // Interfaz para la obtencion de id, precio y nombre de los productos
    // Cada implementacion decide de donde scar esos datos
    interface IProductosFactory
    {
        Producto CreateRefresco();
        Producto CrearPan();
        Producto CrearVerdura();

        Producto CrearProducto(EnumProductos tipoProducto);
    }
}
