﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TiendaAutoservicio
{
    public partial class Form1 : Form
    {

        private DirectorPedidos director_;

        public Form1()
        {
            InitializeComponent();
            
            director_ = new DirectorPedidos(new QRPedidoBuilder(new StaticProductoFactory()));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            QRReader reader = new QRReader();
            string nombre = (string)listBox1.SelectedItem + ".bmp";
            Pedido pr = reader.ReadFile(nombre);

            String newLine = Environment.NewLine;
            String texto = "Nombre Tienda:" + pr.GetNombreTienda();
            texto += newLine + "Costo Total = " + pr.Costo().ToString();


            List<Producto> prs = pr.GetProductos();
            foreach(Producto producto in prs)
            {
                texto += newLine + newLine + "Producto: " + producto.getNombre() + " Cantidad: " + producto.cantidad_ + " Precio Unitario: " + producto.getPrecio();
            }
            textBox1.Text = texto;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            string nombre = (string)listBox1.SelectedItem;

            Dictionary<EnumProductos, int> cantidadProductos = new Dictionary<EnumProductos, int>();
            if (numericPanes.Value != 0) cantidadProductos.Add(EnumProductos.Pan, (int)numericPanes.Value);
            if (numericVerduras.Value != 0) cantidadProductos.Add(EnumProductos.Verdura, (int)numericVerduras.Value);

            if (numericRefrescos.Value != 0) cantidadProductos.Add(EnumProductos.Refresco, (int)numericRefrescos.Value);

            director_.MakePedido(cantidadProductos, index, nombre);
            Console.WriteLine("Listo");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(); // Instantiate a Form3 object.
            f2.Show();
        }
    }
}
