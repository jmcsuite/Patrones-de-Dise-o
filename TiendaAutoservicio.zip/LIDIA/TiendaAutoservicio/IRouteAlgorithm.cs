﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    interface IRouteAlgorithm
    {
        // Recibe una lista de pedidos por surtir y de camiones de un solo producto.
        // Devuelve una lista de pedidos surtidos, y producto faltante.
        Tuple<List<Pedido>, EnumProductos> GetRoute(List<Pedido> pedidosSurtir, List<Producto> camiones);
    }
}
