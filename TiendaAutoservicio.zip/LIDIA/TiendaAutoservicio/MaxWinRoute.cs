﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    // Ordena los pedidos por mayor costo a menor costo. Y los surte en orden
    // Surte los pedidos en ese orden, y si no puede surtir acaba la simulacion
    // Devuelve el primer producto que no se pudo surtir
    
    class MaxWinRoute : IRouteAlgorithm
    {
        public Tuple<List<Pedido>, EnumProductos> GetRoute(List<Pedido> pedidosSurtir, List<Producto> cammiones)
        {
            Console.WriteLine("Perro");
            List<Producto> camiones = new List<Producto>(cammiones);
            List<Pedido> surtidos = new List<Pedido>();
            pedidosSurtir.Sort((a, b) => -1*b.Costo().CompareTo(-1*a.Costo()));

            foreach(Pedido ped in pedidosSurtir)
            {
                List<Producto> prods = ped.GetProductos();
                foreach(Producto prod in prods)
                {
                    int needed = prod.cantidad_;
                    foreach(Producto camion in camiones)
                    {
                        if(camion.cantidad_ > 0 && camion.nombreProducto_ == prod.nombreProducto_){
                            int cantRestada = 0;
                            if(camion.cantidad_ < needed)
                            {
                                cantRestada = camion.cantidad_;
                            }
                            else
                            {
                                cantRestada = needed;
                            }

                            needed -= cantRestada;
                            camion.setCantidad(camion.getCantidad() - cantRestada);
                        }
                        if (needed == 0) break;
                    }
                    if(needed != 0)
                    {
                        EnumProductos faltante = (EnumProductos)prod.getID();
                        return new Tuple<List<Pedido>, EnumProductos>(surtidos, faltante);
                    }
                }
                surtidos.Add(ped);
            }
            return new Tuple<List<Pedido>, EnumProductos>(surtidos, EnumProductos.Dummy);
            
        }
    }
}
