﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TiendaAutoservicio
{
    public partial class Form2 : Form
    {
        private Simulador sim;
        private List<Pedido> pedidos;
        private IEnumerator<Tuple<List<Pedido>, EnumProductos>> enumerator;
        int verdura, pan, refresco;
        public Form2()
        {
            InitializeComponent();
            button2.Hide();
        }

        private List<Pedido> GetPedidos()
        {
            List<Pedido> pedidos = new List<Pedido>();
            QRReader reader = new QRReader();
            string[] Tiendas = new string[3]{"TiendaA.bmp", "TiendaB.bmp", "TiendaC.bmp"};
            foreach(string tienda in Tiendas)
            {
                Pedido pp = reader.ReadFile(tienda);
                pedidos.Add(pp);
            }
            return pedidos;
        }

        private void button2_Click_action()
        { 
            String newLine = Environment.NewLine;
            label1.Text = "";

            labelR.Text = "Camiones de Refresco: " + refresco.ToString();
            labelP.Text = "Camiones de Pan: " + pan.ToString();
            labelV.Text = "Camiones de Verdura: " + verdura.ToString();


            if (enumerator.MoveNext())
            {
                
                Tuple<List<Pedido>, EnumProductos> pp = enumerator.Current;
                label1.Text = "";
                if(pp.Item2 == EnumProductos.Dummy)
                {
                    label1.Text += "No hacen falta camiones!";
                }

                if (pp.Item2 == EnumProductos.Refresco)
                {
                    label1.Text += "Hizo falta camion de refresco!";
                    refresco++;
                }

                if (pp.Item2 == EnumProductos.Pan)
                {
                    label1.Text += "Hizo Falta camion de pan!";
                    pan++;
                }

                if (pp.Item2 == EnumProductos.Verdura)
                {
                    label1.Text += "Hizo falta camion de vegetales!";
                    verdura++;
                }
                Console.WriteLine("Clicked");
                Console.WriteLine(pp.Item2);
                string textT = "";

                float costo = 0;
                foreach(Pedido ped in pp.Item1)
                {
                    costo += ped.Costo();
                    textT += ped.GetNombreTienda();
                    textT += newLine;
                }
                textBox1.Text = textT;
                label2.Text = "Venta generada = $" + costo.ToString();
            }
            else
            {
                label1.Text = "Simulacion Finalizada"; 
            }

            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            verdura = pan = refresco = 0;
            pedidos = GetPedidos();
            sim = new Simulador(new MaxWinRoute(), 3, 3, 3, new CamionesFactory(new StaticProductoFactory()));
            enumerator = (IEnumerator < Tuple<List<Pedido>, EnumProductos> > )sim.Simular(pedidos);
            button2_Click_action();
            button2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2_Click_action();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
