﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    // Interfaz para la generacion de pedidos.
    // La forma en la que se guardan, cambian, inician pedidos se deja a implementacion de las subclases.
    interface IPedidoBuilder
    {
        void Reset(int idTienda, string nombreTienda);

        void AddProduct(EnumProductos tipoProducto, int cantidad);

        void FinalizePedido();
    }
}
