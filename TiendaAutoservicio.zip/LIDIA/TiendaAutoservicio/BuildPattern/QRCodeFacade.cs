﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spire.Barcode;
using System.Drawing;
using MessagingToolkit.QRCode.Codec;
using MessagingToolkit.QRCode.Codec.Data;


namespace TiendaAutoservicio
{

    // Facade de la creacion de codigos de QR.
    class QRCodeFacade
    {
        public QRCodeFacade() { }

        /* Recibe el dato, y el nombreDelArchivo
         * Utiliza las API de SpireBarcode, y System.Drawing para la generacion de la Imagen
         * y para guardarla */
        public void makeQRCode(string data, string nombreTienda)
        {
            

            QRCodeEncoder enc = new QRCodeEncoder();
            Bitmap qrcode = enc.Encode(data);
            Image QRbarcode = qrcode as Image;
           
            File.Delete("./" + nombreTienda);
            QRbarcode.Save("./" + nombreTienda);
        }
    }
}
