﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{

    // Director para generar pedidos
    // El Director se apoya de la interfaz IPedidoBuilder para crear los pedidos
    // En todos los pedidos, primero se resetea el builder, luego se van agreganado uno por uno los productos del pedido
    // Finalmente se guarda el pedido
    class DirectorPedidos
    {
        IPedidoBuilder pedidoBuilder_;

        public DirectorPedidos(IPedidoBuilder builder)
        {
            pedidoBuilder_ = builder;
        }

        public void MakePedido(Dictionary<EnumProductos, int> cantidadProductos, int idTienda, string nombreTienda)
        {
            pedidoBuilder_.Reset(idTienda, nombreTienda);
            foreach(KeyValuePair<EnumProductos, int> entry in cantidadProductos) { 
                pedidoBuilder_.AddProduct(entry.Key, entry.Value);
            }
            pedidoBuilder_.FinalizePedido();
        }
    }
}
