﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace TiendaAutoservicio
{

    // Implementacion de un builder, que genera los pedidos en forma de imagenes QR
    // Para la generacion del QR, transforma el pedido a JSON usando Newtonsoft.Json
    // Para generar la imagen usa QRCodeFacade 
    // Recibe un Factory de Productos para sacar ids, nombres y precios
    class QRPedidoBuilder : IPedidoBuilder
    {

        private IProductosFactory productFactory_;
        private QRCodeFacade QRCodeFacade_ = new QRCodeFacade();
        Pedido pedido_ = null;

        public QRPedidoBuilder(IProductosFactory productFactory)
        {
            productFactory_ = productFactory;
        }

        // Inicia un nuevo pedido, perdiendo la informacion del anterior
        public void Reset(int idTienda, string nombreTienda)
        {
            pedido_ = new Pedido(idTienda, nombreTienda);
        }

        // Agrega un producto con los datos proporcionados por el IProductosFactory
        public void AddProduct(EnumProductos tipoProducto, int cantidad)
        {
            Producto pr = productFactory_.CrearProducto(tipoProducto);
            pr.setCantidad(cantidad);
            pedido_.AddProducto(pr);
        }

        // Transforma el pedido en JSON y genera una imagen QR con ese dato

        public void FinalizePedido()
        {
            pedido_.BeforeSerialize();
            string json = JsonConvert.SerializeObject(pedido_);
            QRCodeFacade_.makeQRCode(json, pedido_.GetNombreTienda() + ".bmp");
        }

        
    }
}
