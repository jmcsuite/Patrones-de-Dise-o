﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TiendaAutoservicio
{
    //Clase con toda la logica para la simulacion de recorridos
    // Recibe un algoritmo para para trazar la ruta.
    // Recibe un IProductosFactory que corresponde a la informacion de cada camion
    // Recibe la maxima cantidad de camiones de verdura, pan y refrescos
    class Simulador
    {
        private IRouteAlgorithm algorithm_;
        private IProductosFactory factory_; 
        public int maxVerdura, maxPan, maxRefresco;

        public Simulador(IRouteAlgorithm algorithm, int verdura_, int pan_, int refresco_, IProductosFactory camionFactory)
        {
            algorithm_ = algorithm;
            maxVerdura = verdura_;
            maxPan = pan_;
            maxRefresco = refresco_;
            factory_ = camionFactory;
            Console.WriteLine("pp2");
        }

        // Enumerador que simula la entrega de pedidos (inicialmente usando 0 camiones) y va agregando 
        // de uno en uno cada camion dependiendo del resultado del algoritmo de ruta
        public IEnumerator<Tuple<List<Pedido>, EnumProductos>> Simular(List<Pedido> pedidos)
        {
            Console.WriteLine("pp1");
            List<Producto> camiones = new List<Producto>();
            int verdura, pan, refresco;
            verdura = pan = refresco = 0;
            Tuple<List<Pedido>, EnumProductos> res = algorithm_.GetRoute(pedidos, camiones);
            
            yield return res;
            Console.WriteLine("pp1");
            while (res.Item2 != EnumProductos.Dummy)
            {
                
                if (verdura >= maxVerdura) break;
                if (pan >= maxPan) break;
                if (refresco >= maxRefresco) break;

                if(res.Item2 == EnumProductos.Pan)
                {
                    Producto camion = factory_.CrearPan();
                    camiones.Add(camion);
                    pan++;
                }

                if (res.Item2 == EnumProductos.Refresco)
                {
                    Producto camion = factory_.CreateRefresco();
                    camiones.Add(camion);
                    refresco++;
                }

                if (res.Item2 == EnumProductos.Verdura)
                {
                    Producto camion = factory_.CrearVerdura();
                    camiones.Add(camion);
                    verdura++;
                }

                res = algorithm_.GetRoute(pedidos, camiones);
                camiones = new List<Producto>();
                Console.WriteLine(camiones.Count);
                for(int i = 0; i < pan; i++)
                {
                    camiones.Add(factory_.CrearPan());
                }

                for (int i = 0; i < verdura; i++)
                {
                    camiones.Add(factory_.CrearVerdura());
                } 

                for (int i = 0; i < refresco; i++)
                {
                    camiones.Add(factory_.CreateRefresco());
                }
                yield return res;
            }


        }
    }
}

